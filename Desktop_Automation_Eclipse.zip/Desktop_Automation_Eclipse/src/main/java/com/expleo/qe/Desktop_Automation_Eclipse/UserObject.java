package com.expleo.qe.Desktop_Automation_Eclipse;

public class UserObject
{
    private String remoteMachineName;
    private String userName;
    private String password;

    public UserObject(String remoteMachineName, String userName, String password)
    {
        setRemoteMachineName(remoteMachineName);
        setUserName(userName);
        setPassword(password);

    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRemoteMachineName() {
        return remoteMachineName;
    }

    public void setRemoteMachineName(String remoteMachineName) {
        this.remoteMachineName = remoteMachineName;
    }

    //////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////

    public static UserObject getUserData()
    {
        return DataAccess.getUserData();
    }
}
