package com.expleo.qe.Desktop_Automation_Eclipse;

import com.betfair.platform.plugin.testprocess.*;
import com.betfair.platform.plugin.testprocess.TestProcess;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.smartbear.testleft.*;
import com.smartbear.testleft.testobjects.*;
import org.openqa.selenium.By;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import java.awt.*;
import java.awt.Window;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.smartbear.testleft.testobjects.TopLevelWindow;
import com.smartbear.testleft.testobjects.TextEdit;
import com.smartbear.testleft.testobjects.WindowPattern;

import javax.swing.*;

public class AppRunner
{

   // public static Driver objDriver;
    static boolean logInERROR = false;
    public static void main(String[] args)
    {
        boolean driverOn = false;

        boolean automateComplete = false;
        boolean remoteLogInError = false;
        
        UserObject obj;
        try
        {
        	
            obj = UserObject.getUserData();
            driverOn = runStarterBatFile();
            System.out.println(".>>>>>>>>>>>>>>>>>>>>>....bat file started = " + driverOn);
            Thread.sleep(10000);

            if(driverOn)
            {
                automateComplete = automateActions3(obj.getRemoteMachineName(), obj.getUserName(), obj.getPassword());

                if (automateComplete)
                {
                    System.out.println("Automation Complete Successful");
                    
                    System.out.println("Stopped process -> " + runEnderBatFile());
                }
                else
                {
                    System.out.println("Automation Complete Unsuccessful");
                    System.out.println("Stopped process -> " + runEnderBatFile());
                }
            }
        }
        catch (Exception e)
        {
            System.out.println("Driver started ->" + driverOn + "\n" +
                    "Automation started -> " + automateComplete + "\n" +
                    e.getMessage());
        }
    }
    
    
    //Working to be tested!!
    public static boolean runStarterBatFile()
    {
        boolean cmdLaunch = false;
        File batFile = new  File("C:\\Desktop_Automation_Eclipse\\resources\\remoteDeskTopStarter.bat");
        try
        {
            if(batFile.exists())
            {
                Runtime.
                        getRuntime().
                        exec("cmd /c start \"\" C:\\Desktop_Automation_Eclipse\\resources\\remoteDeskTopStarter.bat");

                cmdLaunch = true;
            }
            Thread.sleep(9000);
        }
        catch (IOException e)
        {
            cmdLaunch = false;
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        return cmdLaunch;
    }

    public static boolean runEnderBatFile()
    {
        boolean cmdLaunch = false;
        File batFile = new  File("C:\\Desktop_Automation_Eclipse\\resources\\remoteDeskTopEnder.bat");
        try
        {
            if(batFile.exists())
            {
                Runtime.
                        getRuntime().
                        exec("cmd /c start \"\" C:\\Desktop_Automation_Eclipse\\resources\\remoteDeskTopEnder.bat");

                cmdLaunch = true;
            }
            Thread.sleep(9000);
        }
        catch (IOException e)
        {
            cmdLaunch = false;
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        return cmdLaunch;
    }




    public static boolean automateActions3(String remoteMachineName, String userName,String password)
    		throws MalformedURLException, HttpException, TestAgentRunException, RestConnectionRefused, ObjectTreeNodeNotFoundException, InvocationException 
    {
        boolean executed = false;
        boolean defaultWhileCondition = true;

        DesktopOptions options = new DesktopOptions();
        options.setApplicationPath("C:/WINDOWS/system32/mstsc.exe");
        WiniumDriver objDriver = new WiniumDriver(new URL("http://localhost:9999"),options);

        try
        {
            System.out.println("Automation3()");
            Thread.sleep(2000);
            //Send machineName
            objDriver.findElement(By.id("5012")).sendKeys(remoteMachineName);
            //Click on OK
            objDriver.findElement(By.id("1")).click();
            //Wait for the machine to be found
                while(defaultWhileCondition)
                {
                    if(objDriver.findElement(By.id("5025")).isDisplayed())
                    {
                        Thread.sleep(2000);
                        System.out.println("waiting");
                    }
                    else if(objDriver.findElement(By.id("ContentText")).isDisplayed())
                    {
                        defaultWhileCondition = false;
                        System.out.println("error found...");
                    }
                }
        }
        catch (Exception e)
        {
        		 //check if error screen is displayed
                if(objDriver.findElement(By.id("ContentText")).isDisplayed())
                {
                    System.out.println("Error screen found");
                    objDriver.findElement(By.id("CommandButton_1")).click();
                    objDriver.findElement(By.name("Close")).click();
                    
                    executed = true;
                }
                else // check if passWord feild is visible
                {
                	//Add else if(passwordScreen isDisplayed == true)
                    //{
                    //      enter password
                    //      click login
                    //      wait for Windows log in screen
                    //      executed = true;
                    //}
                    //then proceed with the necessary steps
                }      		 
        }
        return executed;
    }  
}
