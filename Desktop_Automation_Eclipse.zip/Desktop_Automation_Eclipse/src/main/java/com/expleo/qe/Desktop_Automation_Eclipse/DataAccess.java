package com.expleo.qe.Desktop_Automation_Eclipse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

class DataAccess
{
    private static File userData = new File("C:\\Desktop_Automation_Eclipse\\resources\\UserObject.txt");

    static UserObject getUserData()
    {
        UserObject objUser = null;
        String fileLine;
        String remoteMachineName, userName, password;
        int lineCounter = 0;

        try
        {
            FileInputStream fis = new FileInputStream(userData);
            BufferedReader muInput = new BufferedReader(new InputStreamReader(fis));

            if (userData.exists())
            {
                while(((fileLine = muInput.readLine()) != null))
                {
                    StringTokenizer st = new StringTokenizer(fileLine,",");

                    if (lineCounter != 0)
                    {
                        while (st.hasMoreElements())
                        {
                            remoteMachineName = st.nextToken();
                            userName = st.nextToken();
                            password = st.nextToken();
                            objUser = new UserObject(remoteMachineName,userName,password);
                        }
                    }
                    lineCounter ++;
                }
                muInput.close();
            }
        }
        catch (Exception e)
        {
            System.out.println("User file reading Error \n"
                             +   e.getMessage() + "\n");
        }
        return objUser;
    }

}
